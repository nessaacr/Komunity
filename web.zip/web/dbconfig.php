<?php
$servername = "localhost";
$username = "root";
$password = "mypass";
$dbname = "komunity";
?>