<!DOCTYPE html>
<html lang="en">
<head>
    <title>KomUnity - Konfirmasi Positif</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/konfirmasipositif.css">
    <link rel='stylesheet' type="text/css" href='https://fonts.googleapis.com/css?family=Montserrat' />
</head>

<body>
<div id="container">
    <header>
        <ul id="navbar">
            <li><a href="dashboard.php">Home.../</a></li>
            <li><a href="#">Konfirmasi.../</a></li>
            <li><a href="#">Jumlah.../</a></li>
            <li><a href="konfirmasipositif.php">Konfirmasi Positif</a></li><br>
        </ul>
    </header>

    <div>
        <div id="report-title">
            <h1>Konfirmasi Positif</h1>
        </div>

        <div class="identity">
            <div class="identity-content">
                <p class="content-title">Nama Lengkap</p>
                <p class="content-data">John Doe</p>
            </div>
            <div class="identity-content">
                <p class="content-title">NIK</p>
                <p class="content-data">0123456789012345</p>
            </div>
            <div class="identity-content">
                <p class="content-title">No Telepon</p>
                <p class="content-data">+62 825 3637 7937</p>
            </div>    
        </div>   
    </div>

    <a class="report-button" href="#">Konfirmasi Positif &emsp;&emsp;&emsp; &rarr;</a>

    <footer>
        <div id="footer-content">
            <a href="tentang-komunity.php" class="footer-link">About KomUnity</a>
            <a href="kebijakan-privasi.php" class="footer-link">Privacy Policy</a><br>
            <img class="footer-icon" src="img/komunity-icon.png">
            <p class="copyright">KomUnity © 2021</p>
        </div>
    </footer>
</div>
</div>
</body>

</html>