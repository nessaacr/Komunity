function openNav() {
    document.getElementById("dashboard-sidenav").style.width = "100%";
  }
  
  function closeNav() {
    document.getElementById("dashboard-sidenav").style.width = "0";
  }