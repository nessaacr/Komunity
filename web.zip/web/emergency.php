<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KomUnity - Panggilan Darurat</title>
    <link rel="stylesheet" href="css/emergency.css">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Varela+Round" />
    <link rel='stylesheet' type="text/css" href='https://fonts.googleapis.com/css?family=Montserrat' />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3pro.css">
</head>
<body>
<div id="container">
    <img src="img/panggilan-darurat-icon.png" class="icon">
    <h1>Panggilan Darurat</h1><br>
    <a href="#" ><img src="img/ambulans.png" class="top-button"></a><br><br>
    <a href="#" ><img src="img/pemadam-kebakaran.png" class="top-button"></a>
    <h2>Layanan Darurat Lainnya</h2>
    <a href="#"><img src="img/layanan-medis-rumah.png" class="bot-button"></a>
    <a href="#"><img src="img/lapor-error-keluhan.png" class="bot-button"></a><br><br>

    <footer>
        <a href="tentang-komunity.php" class="footer-link">About KomUnity</a>
        <a href="kebijakan-privasi.php" class="footer-link">Privacy Policy</a><br>
        <img class="footer-icon" src="img/komunity-icon.png">
        <p class="copyright">KomUnity © 2021</p>
    </footer>
</div>
</body>
</html>