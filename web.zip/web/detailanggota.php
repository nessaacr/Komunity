<!DOCTYPE html>
<html lang="en">
<head>
    <title>KomUnity - Detail Anggota</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/detailanggota.css">
    <link rel='stylesheet' type="text/css" href='https://fonts.googleapis.com/css?family=Montserrat' />
</head>

<body>
<div id="container">
    <header>
        <ul id="navbar">
            <li><a href="dashboard.php">Homepage/</a></li>
            <li><a href="profil-akun-penghuni.php">Profil Anggota</a></li>
            <br>
        </ul>
    </header>

    <div>
        <div id="profile">
            <img id="profile-pict" src="img/profilebg.jpg">
            <div id="container-name"><h1 id="name-title">John Doe</h1></div>
        </div>

        <div class="identity">
            <div class="identity-content">
                <p class="content-title">Nama Lengkap</p>
                <p class="content-data">John Doe</p>
            </div>
            <div class="identity-content">
                <p class="content-title">NIK</p>
                <p class="content-data">0123456789012345</p>
            </div>
            <div class="identity-content">
                <p class="content-title">No Telepon</p>
                <p class="content-data">+62 825 3637 7937</p>
            </div> 
            <div class="identity-content">
                <p class="pcr-title">Hasil Tes PCR Negatif</p>
                <div id="input-pcr"></div>
            </div>    
        </div>   
    </div>

    <a class="report-button" href="konfirmasi-negatif.php">Lapor Negatif &emsp;&emsp;&emsp;&emsp; &rarr;</a>

    <footer>
        <div id="footer-content">
            <a href="tentang-komunity.php" class="footer-link">About KomUnity</a>
            <a href="kebijakan-privasi.php" class="footer-link">Privacy Policy</a><br>
            <img class="footer-icon" src="img/komunity-icon.png">
            <p class="copyright">KomUnity © 2021</p>
        </div>
    </footer>
</div>
</div>
</body>

</html>