<!DOCTYPE html>
<html lang="en">
<head>
    <title>KomUnity - Laporan Negatif - Admin</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/laporannegatif-admin.css">
    <link rel='stylesheet' type="text/css" href='https://fonts.googleapis.com/css?family=Montserrat' />
</head>

<body>
<div id="container">
    <header>
        <ul id="navbar">
            <li><a href="dashboard.php">Home.../</a></li>
            <li><a href="#">Konfirmasi.../</a></li>
            <li><a href="#">Laporan Negatif</a></li><br>
        </ul>
    </header>

    <div>
        <div id="report-title">
            <h1>Laporan Negatif</h1>
        </div>

        <a href=riwayatpositif.php id="riwayat">lihat riwayat</a>

        <div class="container-person">
            <a href="informasi-riwayat.php">
                <div class=name-button>
                    <p class="name">Adam Smith</p>
                    <p class="number">0123456789012345</p>
                </div>
            </a>
            <a href="informasi-riwayat.php">
                <div class=name-button>
                    <p class="name">John D.</p>
                    <p class="number">0123456789012345</p>
                </div>
            </a>
            <a href="informasiriwayat.php">
                <div class=name-button>
                    <p class="name">Jane Doe</p>
                    <p class="number">0123456789012345</p>
                </div>
            </a>
            <a href="informasiriwayat.php">
                <div class=name-button>
                    <p class="name">Mary Jane</p>
                    <p class="number">0123456789012345</p>
                </div>
            </a>
        </div>
        
    </div>



    <footer>
        <div id="footer-content">
            <a href="#" class="footer-link">About KomUnity</a>
            <a href="#" class="footer-link">Privacy Policy</a><br>
            <img class="footer-icon" src="img/komunity-icon.png">
            <p class="copyright">KomUnity © 2021</p>
        </div>
    </footer>
</div>
</div>
</body>
</html>